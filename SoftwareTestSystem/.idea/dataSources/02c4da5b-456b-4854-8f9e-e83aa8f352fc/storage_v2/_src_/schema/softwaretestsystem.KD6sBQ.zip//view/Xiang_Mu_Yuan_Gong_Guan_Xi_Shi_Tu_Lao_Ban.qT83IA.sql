create view 项目员工关系视图老版 as select `softwaretestsystem`.`项目经理关系`.`项目编号` AS `项目编号`,
                                 `员工总表`.`编号`                          AS `编号`,
                                 `员工总表`.`姓名`                          AS `姓名`,
                                 `员工总表`.`密码`                          AS `密码`,
                                 `员工总表`.`性别`                          AS `性别`,
                                 `员工总表`.`邮箱`                          AS `邮箱`
                          from (`softwaretestsystem`.`项目经理关系` join `softwaretestsystem`.`员工总表`)
                          where (`softwaretestsystem`.`项目经理关系`.`项目经理编号` = `员工总表`.`编号`)
                          union select `softwaretestsystem`.`项目产品经理关系`.`项目编号` AS `项目编号`,
                                       `员工总表`.`编号`                            AS `编号`,
                                       `员工总表`.`姓名`                            AS `姓名`,
                                       `员工总表`.`密码`                            AS `密码`,
                                       `员工总表`.`性别`                            AS `性别`,
                                       `员工总表`.`邮箱`                            AS `邮箱`
                                from (`softwaretestsystem`.`项目产品经理关系` join `softwaretestsystem`.`员工总表`)
                                where (`softwaretestsystem`.`项目产品经理关系`.`产品经理编号` = `员工总表`.`编号`)
                          union select `softwaretestsystem`.`项目开发者关系`.`项目编号` AS `项目编号`,
                                       `员工总表`.`编号`                           AS `编号`,
                                       `员工总表`.`姓名`                           AS `姓名`,
                                       `员工总表`.`密码`                           AS `密码`,
                                       `员工总表`.`性别`                           AS `性别`,
                                       `员工总表`.`邮箱`                           AS `邮箱`
                                from (`softwaretestsystem`.`项目开发者关系` join `softwaretestsystem`.`员工总表`)
                                where (`softwaretestsystem`.`项目开发者关系`.`开发者编号` = `员工总表`.`编号`)
                          union select `softwaretestsystem`.`项目测试者关系`.`项目编号` AS `项目编号`,
                                       `员工总表`.`编号`                           AS `编号`,
                                       `员工总表`.`姓名`                           AS `姓名`,
                                       `员工总表`.`密码`                           AS `密码`,
                                       `员工总表`.`性别`                           AS `性别`,
                                       `员工总表`.`邮箱`                           AS `邮箱`
                                from (`softwaretestsystem`.`项目测试者关系` join `softwaretestsystem`.`员工总表`)
                                where (`softwaretestsystem`.`项目测试者关系`.`测试者编号` = `员工总表`.`编号`);

