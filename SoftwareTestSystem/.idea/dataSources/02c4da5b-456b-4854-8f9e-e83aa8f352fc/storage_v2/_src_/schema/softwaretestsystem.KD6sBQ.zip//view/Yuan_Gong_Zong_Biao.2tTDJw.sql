create view 员工总表 as select `softwaretestsystem`.`管理员`.`管理员编号` AS `管理员编号`,
                           `softwaretestsystem`.`管理员`.`管理员姓名` AS `管理员姓名`,
                           `softwaretestsystem`.`管理员`.`管理员密码` AS `管理员密码`,
                           `softwaretestsystem`.`管理员`.`管理员性别` AS `管理员性别`,
                           `softwaretestsystem`.`管理员`.`管理员邮箱` AS `管理员邮箱`,
                           `softwaretestsystem`.`管理员`.`部门`    AS `部门`
                    from `softwaretestsystem`.`管理员`
                    union select `softwaretestsystem`.`项目经理`.`项目经理编号` AS `项目经理编号`,
                                 `softwaretestsystem`.`项目经理`.`项目经理姓名` AS `项目经理姓名`,
                                 `softwaretestsystem`.`项目经理`.`项目经理密码` AS `项目经理密码`,
                                 `softwaretestsystem`.`项目经理`.`项目经理性别` AS `项目经理性别`,
                                 `softwaretestsystem`.`项目经理`.`项目经理邮箱` AS `项目经理邮箱`,
                                 `softwaretestsystem`.`项目经理`.`部门`     AS `部门`
                          from `softwaretestsystem`.`项目经理`
                    union select `softwaretestsystem`.`产品经理`.`产品经理编号` AS `产品经理编号`,
                                 `softwaretestsystem`.`产品经理`.`产品经理姓名` AS `产品经理姓名`,
                                 `softwaretestsystem`.`产品经理`.`产品经理密码` AS `产品经理密码`,
                                 `softwaretestsystem`.`产品经理`.`产品经理性别` AS `产品经理性别`,
                                 `softwaretestsystem`.`产品经理`.`产品经理邮箱` AS `产品经理邮箱`,
                                 `softwaretestsystem`.`产品经理`.`部门`     AS `部门`
                          from `softwaretestsystem`.`产品经理`
                    union select `softwaretestsystem`.`开发者`.`开发者编号` AS `开发者编号`,
                                 `softwaretestsystem`.`开发者`.`开发者姓名` AS `开发者姓名`,
                                 `softwaretestsystem`.`开发者`.`开发者密码` AS `开发者密码`,
                                 `softwaretestsystem`.`开发者`.`开发者性别` AS `开发者性别`,
                                 `softwaretestsystem`.`开发者`.`开发者邮箱` AS `开发者邮箱`,
                                 `softwaretestsystem`.`开发者`.`部门`    AS `部门`
                          from `softwaretestsystem`.`开发者`
                    union select `softwaretestsystem`.`测试者`.`测试者编号` AS `测试者编号`,
                                 `softwaretestsystem`.`测试者`.`测试者姓名` AS `测试者姓名`,
                                 `softwaretestsystem`.`测试者`.`测试者密码` AS `测试者密码`,
                                 `softwaretestsystem`.`测试者`.`测试者性别` AS `测试者性别`,
                                 `softwaretestsystem`.`测试者`.`测试者邮箱` AS `测试者邮箱`,
                                 `softwaretestsystem`.`测试者`.`部门`    AS `部门`
                          from `softwaretestsystem`.`测试者`;

