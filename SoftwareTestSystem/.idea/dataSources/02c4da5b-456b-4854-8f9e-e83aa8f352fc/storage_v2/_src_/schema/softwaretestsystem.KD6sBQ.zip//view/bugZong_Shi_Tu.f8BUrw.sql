create view bug总视图 as
  select `softwaretestsystem`.`bug`.`BUG编号` AS `BUG编号`,
         `softwaretestsystem`.`bug`.`BUG名称` AS `BUG名称`,
         `softwaretestsystem`.`bug`.`类型`    AS `类型`,
         `softwaretestsystem`.`测试者`.`测试者编号` AS `测试者编号`,
         `softwaretestsystem`.`测试者`.`测试者姓名` AS `测试者姓名`,
         `softwaretestsystem`.`开发者`.`开发者编号` AS `开发者编号`,
         `softwaretestsystem`.`开发者`.`开发者姓名` AS `开发者姓名`,
         `softwaretestsystem`.`bug`.`方案`    AS `方案`,
         `softwaretestsystem`.`bug`.`执行时间`  AS `执行时间`
  from `softwaretestsystem`.`bug`
         join `softwaretestsystem`.`测试者`
         join (`softwaretestsystem`.`bug工作者关系` left join `softwaretestsystem`.`开发者` on ((
    `softwaretestsystem`.`开发者`.`开发者编号` = `softwaretestsystem`.`bug工作者关系`.`开发者编号`)))
  where ((`softwaretestsystem`.`bug`.`BUG编号` = `softwaretestsystem`.`bug工作者关系`.`BUG编号`) and
         (`softwaretestsystem`.`测试者`.`测试者编号` = `softwaretestsystem`.`bug工作者关系`.`测试者编号`));

