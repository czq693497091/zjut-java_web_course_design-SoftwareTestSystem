create view 任务总视图 as
  select `softwaretestsystem`.`任务`.`任务编号`     AS `任务编号`,
         `softwaretestsystem`.`项目任务关系`.`项目编号` AS `项目编号`,
         `softwaretestsystem`.`任务`.`任务名称`     AS `任务名称`,
         `softwaretestsystem`.`项目经理`.`项目经理编号` AS `项目经理编号`,
         `softwaretestsystem`.`项目经理`.`项目经理姓名` AS `项目经理姓名`,
         `softwaretestsystem`.`产品经理`.`产品经理编号` AS `产品经理编号`,
         `softwaretestsystem`.`产品经理`.`产品经理姓名` AS `产品经理姓名`,
         `softwaretestsystem`.`开发者`.`开发者编号`   AS `开发者编号`,
         `softwaretestsystem`.`开发者`.`开发者姓名`   AS `开发者姓名`,
         `softwaretestsystem`.`测试者`.`测试者编号`   AS `测试者编号`,
         `softwaretestsystem`.`测试者`.`测试者姓名`   AS `测试者姓名`,
         `softwaretestsystem`.`任务`.`完成状态`     AS `完成状态`,
         `softwaretestsystem`.`任务`.`开始日期`     AS `开始日期`,
         `softwaretestsystem`.`任务`.`截止日期`     AS `截止日期`
  from `softwaretestsystem`.`任务`
         join `softwaretestsystem`.`项目任务关系`
         join `softwaretestsystem`.`项目经理`
         join `softwaretestsystem`.`产品经理`
         join `softwaretestsystem`.`项目经理关系`
         join `softwaretestsystem`.`项目`
         join (`softwaretestsystem`.`任务员工关系` left join (`softwaretestsystem`.`开发者` join `softwaretestsystem`.`测试者`) on ((
    (`softwaretestsystem`.`开发者`.`开发者编号` = `softwaretestsystem`.`任务员工关系`.`开发者编号`) and
    (`softwaretestsystem`.`测试者`.`测试者编号` = `softwaretestsystem`.`任务员工关系`.`测试者编号`))))
  where ((`softwaretestsystem`.`任务`.`任务编号` = `softwaretestsystem`.`任务员工关系`.`任务编号`) and
         (`softwaretestsystem`.`项目任务关系`.`任务编号` = `softwaretestsystem`.`任务员工关系`.`任务编号`) and
         (`softwaretestsystem`.`项目任务关系`.`项目编号` = `softwaretestsystem`.`项目`.`项目编号`) and
         (`softwaretestsystem`.`项目`.`项目编号` = `softwaretestsystem`.`项目经理关系`.`项目编号`) and
         (`softwaretestsystem`.`项目经理关系`.`项目经理编号` = `softwaretestsystem`.`项目经理`.`项目经理编号`) and
         (`softwaretestsystem`.`产品经理`.`产品经理编号` = `softwaretestsystem`.`任务员工关系`.`产品经理编号`));

