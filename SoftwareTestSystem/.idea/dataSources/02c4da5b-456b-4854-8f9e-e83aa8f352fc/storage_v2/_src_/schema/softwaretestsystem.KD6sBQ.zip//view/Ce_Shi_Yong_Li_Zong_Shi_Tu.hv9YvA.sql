create view 测试用例总视图 as
  select `softwaretestsystem`.`测试用例`.`测试用例编号` AS `测试用例编号`,
         `softwaretestsystem`.`测试用例`.`测试用例名称` AS `测试用例名称`,
         `softwaretestsystem`.`测试用例`.`类型`     AS `类型`,
         `c`.`测试者编号`                          AS `创建人编号`,
         `c`.`测试者姓名`                          AS `创建人`,
         `d`.`测试者编号`                          AS `执行人编号`,
         `d`.`测试者姓名`                          AS `执行人`,
         `softwaretestsystem`.`测试用例`.`结果`     AS `结果`,
         `softwaretestsystem`.`测试用例`.`状态`     AS `状态`,
         `softwaretestsystem`.`测试用例`.`执行时间`   AS `执行时间`
  from `softwaretestsystem`.`测试用例`
         join `softwaretestsystem`.`测试者` `c`
         join (`softwaretestsystem`.`测试用例测试者关系` left join `softwaretestsystem`.`测试者` `d` on ((`d`.`测试者编号` =
                                                                                              `softwaretestsystem`.`测试用例测试者关系`.`指定测试者编号`)))
  where ((`softwaretestsystem`.`测试用例`.`测试用例编号` = `softwaretestsystem`.`测试用例测试者关系`.`测试用例编号`) and
         (`c`.`测试者编号` = `softwaretestsystem`.`测试用例测试者关系`.`测试者编号`));

